/**************************************************************************
  Class: ECE508 Spring 2026
  Student Name: Sirawich Sutthawaho
  Gnumber: Gxxxx3925
  Date: 04/24/2026
  HW: Final Project — Nano33 Sensor Node (Switch Mode)
 **************************************************************************/

#include <stdio.h>
#include "myiot33_library.h"
#include <FreeRTOS_SAMD21.h>
#include <Wire.h>
#include <Adafruit_SHT31.h>
#include <SensirionI2cScd4x.h>
#include "Adafruit_PM25AQI.h"

#ifdef NO_ERROR
#undef NO_ERROR
#endif
#define NO_ERROR 0

#define I2C_SLAVE_ADDR  0x08
#define JSON_BUF_SIZE   220

static char ptrTaskList[400];

#define ERROR_LED_PIN  13
#define ERROR_LED_LIGHTUP_STATE  HIGH

//*************************************************************
// Config
//*************************************************************
const char gNumber[15] = "Gxxxx3925";
const char TEAM_NUM[]  = "team03";

// Mode timing
#define MASTER_DURATION_MS  500   // read sensor 1.5 second
#define SLAVE_DURATION_MS   500    // open slave 0.5 second

//*************************************************************
// Task Handles
//*************************************************************
TaskHandle_t Handle_TaskMain;
TaskHandle_t Handle_TaskMonitor;

//*************************************************************
// Objects
//*************************************************************
Adafruit_SHT31    sht31;
SensirionI2cScd4x sensor;
Adafruit_PM25AQI  aqi = Adafruit_PM25AQI();

//*************************************************************
// Shared Variables
//*************************************************************
volatile float myTemp    = 0.0;
volatile float myHumid   = 0.0;
volatile float myCo2     = 0.0;
volatile uint16_t myPm1  = 0;
volatile uint16_t myPm25 = 0;
volatile uint16_t myPm10 = 0;

bool pms5003_ok = false;
volatile long i2cRequestCount = 0;
volatile long readCycles = 0;

// Mode flag — true = Master mode, false = Slave mode
volatile bool isMasterMode = true;

// JSON buffer
char jsonBuffer[JSON_BUF_SIZE];

//*************************************************************
// OLED
//*************************************************************
const int oledLib = 1;    
String oledline[9];
char oledBuffer[64];
bool oledReady = false;

//*************************************************************
// Prototypes
//*************************************************************
void TaskMain(void *pvParameters);
void TaskMonitor(void *pvParameters);
void onI2CRequest();
void buildJSON();
void switchToMaster();
void switchToSlave();
void readAllSensors();
void updateOLED();

void myDelayMs(int ms) { vTaskDelay((ms * 1000) / portTICK_PERIOD_US); }

//*************************************************************
void setup() {
  Serial.begin(115200);
  pinMode(LED_BUILTIN, OUTPUT);

  delay(2000);

  Serial.println("");
  Serial.println("******************************");
  Serial.println("  Nano33 Sensor Node v2       ");
  Serial.println("  Switch Mode (Wire only)     ");
  Serial.println("  OLED enabled in Master mode ");
  Serial.println("******************************");
  Serial.flush();

  // ── Start in Master mode ──
  Wire.begin();
  delay(50);

  // ── OLED init while Nano is in Master mode ──
  iot33StartOLED(oledLib);
  oledReady = true;

  oledline[1] = String(gNumber) + " " + String(TEAM_NUM);
  for (int i = 2; i <= 8; i++) {
    oledline[i] = "";
  }
  oledline[2] = "OLED Ready";
  displayTextOLED(oledline, oledLib);
  delay(500);

  // SHT31
  if (!sht31.begin(0x44)) Serial.println("SHT31 not found!");
  else Serial.println("SHT31 OK");

  // SCD41
  sensor.begin(Wire, SCD41_I2C_ADDR_62);
  delay(30);
  sensor.wakeUp();
  sensor.stopPeriodicMeasurement();
  sensor.reinit();
  uint64_t serialNumber = 0;
  int16_t scdErr = sensor.getSerialNumber(serialNumber);
  if (scdErr != NO_ERROR) Serial.println("SCD41 not found!");
  else {
    Serial.println("SCD41 OK");
    sensor.startPeriodicMeasurement();
  }

  // PMS5003 (UART — separate from I2C)
  Serial1.begin(9600);
  delay(1000);
  if (!aqi.begin_UART(&Serial1)) {
    Serial.println("PMS5003 not found!");
    pms5003_ok = false;
  } else {
    Serial.println("PMS5003 OK");
    pms5003_ok = true;
  }

  // Build initial JSON
  buildJSON();

  Serial.println("Setup complete — entering main loop");
  Serial.flush();

  vSetErrorLed(ERROR_LED_PIN, ERROR_LED_LIGHTUP_STATE);
  vSetErrorSerial(&Serial);

  // ── RTOS Tasks ──
  xTaskCreate(TaskMain,    "Main",    2048, NULL, 3, &Handle_TaskMain);
  xTaskCreate(TaskMonitor, "Monitor", 512,  NULL, 1, &Handle_TaskMonitor);

  vTaskStartScheduler();

  while (1) {
    Serial.println("Scheduler Failed!");
    delay(1000);
  }
}

void loop() { }

/*--------------------------------------------------*/
/*---------------------- Tasks ---------------------*/
/*--------------------------------------------------*/

// Main task — alternates between Master and Slave mode
void TaskMain(void *pvParameters) {
  (void) pvParameters;
  Serial.println("Task Main: Started");

  for (;;) {
    // ─────── PHASE 1: MASTER mode (read sensors + OLED) ───────
    switchToMaster();
    readAllSensors();
    buildJSON();
    updateOLED();

    digitalWrite(LED_BUILTIN, !digitalRead(LED_BUILTIN));

    Serial.print("[M#"); Serial.print(readCycles);
    Serial.print("] T:"); Serial.print(myTemp, 1);
    Serial.print(" H:"); Serial.print(myHumid, 0);
    Serial.print(" CO2:"); Serial.print(myCo2, 0);
    Serial.print(" PM2.5:"); Serial.print(myPm25);
    Serial.println();

    myDelayMs(MASTER_DURATION_MS);

    // ─────── PHASE 2: SLAVE mode (serve ESP32) ───────
    switchToSlave();

    Serial.print("[S] Slave open. Total I2C req: ");
    Serial.println(i2cRequestCount);

    myDelayMs(SLAVE_DURATION_MS);

    readCycles++;
  }
}

void TaskMonitor(void *pvParameters) {
  (void) pvParameters;
  int measurement;
  Serial.println("Task Monitor: Started");

  for (;;) {
    myDelayMs(15000);

    Serial.println("");
    Serial.println("****************************************************");
    Serial.print("Free Heap: ");
    Serial.print(xPortGetFreeHeapSize());
    Serial.println(" bytes");
    Serial.print("Read cycles:    "); Serial.println(readCycles);
    Serial.print("I2C requests:   "); Serial.println(i2cRequestCount);
    Serial.print("Latest JSON:    "); Serial.println(jsonBuffer);
    Serial.println("****************************************************");

    measurement = uxTaskGetStackHighWaterMark(Handle_TaskMain);
    Serial.print("Main:    "); Serial.println(measurement);
    measurement = uxTaskGetStackHighWaterMark(Handle_TaskMonitor);
    Serial.print("Monitor: "); Serial.println(measurement);
    Serial.println("****************************************************");
    Serial.flush();
  }
}

//*************************************************************
// Mode Switching
//*************************************************************
void switchToMaster() {
  Wire.end();
  delay(5);
  Wire.begin();          // Master mode
  delay(5);
  isMasterMode = true;
}

void switchToSlave() {
  Wire.end();
  delay(5);
  Wire.begin(I2C_SLAVE_ADDR);   // Slave mode at 0x08
  Wire.onRequest(onI2CRequest);
  delay(5);
  isMasterMode = false;
}

//*************************************************************
// Read all sensors (only in Master mode)
//*************************************************************
void readAllSensors() {
  // SHT31
  float t = sht31.readTemperature();
  float h = sht31.readHumidity();
  if (!isnan(t)) myTemp = t;
  if (!isnan(h)) myHumid = h;

  // SCD41
  bool dataReady = false;
  uint16_t co2Concentration = 0;
  float tempScd = 0, humScd = 0;
  sensor.getDataReadyStatus(dataReady);
  if (dataReady) {
    int16_t err = sensor.readMeasurement(co2Concentration, tempScd, humScd);
    if (err == NO_ERROR && co2Concentration != 0) {
      myCo2 = (float)co2Concentration;
    }
  }

  // PMS5003 (UART — works regardless of I2C mode)
  if (pms5003_ok) {
    PM25_AQI_Data pmData;
    if (aqi.read(&pmData)) {
      myPm1  = pmData.pm10_env;
      myPm25 = pmData.pm25_env;
      myPm10 = pmData.pm100_env;
    }
  }
}

//*************************************************************
// OLED update (only during Master mode)
//*************************************************************
void updateOLED() {
  if (!oledReady) return;
  if (!isMasterMode) return;   

  oledline[1] = String(gNumber) + " " + String(TEAM_NUM);
  oledline[2] = "T:" + String(myTemp, 1) + "C H:" + String(myHumid, 0) + "%";
  oledline[3] = "CO2: " + String(myCo2, 0) + " ppm";
  oledline[4] = "PM1: " + String(myPm1) + " ug/m3";
  oledline[5] = "PM2.5:" + String(myPm25) + " ug/m3";
  oledline[6] = "PM10:" + String(myPm10) + " ug/m3";
  oledline[7] = "I2C Req:" + String(i2cRequestCount);

  convDDHHMMSS(millis() / 1000, oledBuffer);
  oledline[8] = "Up:" + String(oledBuffer);

  displayTextOLED(oledline, oledLib);
}

//*************************************************************
// I2C Request handler (only fires when in Slave mode)
//*************************************************************
void onI2CRequest() {
  i2cRequestCount++;
  Wire.write((uint8_t*)jsonBuffer, strlen(jsonBuffer));
}

//*************************************************************
// Build JSON (ECE508 spec: all values as strings)
//*************************************************************
void buildJSON() {
  snprintf(jsonBuffer, JSON_BUF_SIZE,
    "{\"team\":\"%s\",\"gnumber\":\"%s\",\"temp\":\"%.1f\",\"humid\":\"%.1f\",\"co2\":\"%.0f\",\"pm1\":\"%u\",\"pm25\":\"%u\",\"pm10\":\"%u\",\"uptime\":\"%lu\"}",
    TEAM_NUM, gNumber,
    myTemp, myHumid, myCo2,
    myPm1, myPm25, myPm10,
    (unsigned long)(millis()/1000));
}
