#ifndef MYIOT33_LIBRARY_H
#define MYIOT33_LIBRARY_H


#include <Arduino.h>


int addTwoInts(int a, int b);

void esp32StartOLED(int oledLibrary);
void displayTextOLED(String oledline[9], int oledLibrary);

void esp32StartOLED_Ascii(void);
void displayTextOLED_Ascii(String oledline[9]);
void displayTextOLED_Adafruit(String oledline[9]);
void esp32StartOLED_Adafruit(void);

void convHHMMSS(unsigned long currSeconds, char *uptimeHHMMSS);
void convDDHHMMSS(unsigned long currSeconds, char *uptimeDDHHMMSS);
void convCurrentTimeET(unsigned long currSeconds, char *currentTimeET);

void getWiFiRSSI(char *wifiRSSI);
void getMacWifiShield(char *macWifiShield);
void getMacRouterESP32(char *macRouter);
void getMacWifiShieldMacRouterSS(char *macCombined);

#endif
