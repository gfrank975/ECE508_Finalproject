/**************************************************************************
  ESP32 Gateway — FreeRTOS Version
  Nano33 IoT -> I2C JSON -> ESP32 -> HiveMQ + Shiftr

  Tasks:
  - TaskWiFi: maintain WiFi
  - TaskI2C: read Nano33 through I2C every 1 second
  - TaskMQTT: publish HiveMQ every 1 sec, Shiftr every 3 sec
  - TaskMonitor: print system stats
 **************************************************************************/

#include <Wire.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>

//*************************************************************
// WiFi Config
//*************************************************************
const char* SSID = "SETUP-17CD";
const char* PASS = "common6166canal";

//*************************************************************
// I2C Config
//*************************************************************
#define I2C_SDA         4
#define I2C_SCL         5
#define NANO_ADDR       0x08
#define I2C_BUF_SIZE    220

//*************************************************************
// MQTT Config
//*************************************************************
const char* SHIFTR_HOST = "public.cloud.shiftr.io";
const char* SHIFTR_USER = "public";
const char* SHIFTR_PASS = "public";
const int   SHIFTR_PORT = 1883;

const char* HIVE_HOST = "7625589d1eb542498056b6bebeb1d0a2.s1.eu.hivemq.cloud";
const char* HIVE_USER = "sirawich333";
const char* HIVE_PASS = "Afaps_Crma/5970";
const int   HIVE_PORT = 8883;

const char* TEAM_NUM = "team03";
const char* G_NUMBER = "Gxxxx3925";

//*************************************************************
// Timing
//*************************************************************
const unsigned long I2C_READ_INTERVAL_MS = 1000;   // read Nano every 1 sec
const unsigned long HIVE_INTERVAL_MS     = 1000;   // Hive every 1 sec
const unsigned long SHIFTR_INTERVAL_MS   = 3000;   // Shiftr every 3 sec

//*************************************************************
// Objects
//*************************************************************
WiFiClient        wifiPlain;
WiFiClientSecure  wifiSSL;
PubSubClient      mqttShiftr(wifiPlain);
PubSubClient      mqttHive(wifiSSL);

//*************************************************************
// RTOS Handles
//*************************************************************
TaskHandle_t Handle_TaskWiFi;
TaskHandle_t Handle_TaskI2C;
TaskHandle_t Handle_TaskMQTT;
TaskHandle_t Handle_TaskMonitor;

SemaphoreHandle_t dataMutex;

//*************************************************************
// Shared Data
//*************************************************************
char latestJson[I2C_BUF_SIZE];
bool hasLatestData = false;

volatile long readAttempts = 0;
volatile long readSuccess  = 0;
volatile long sentHive     = 0;
volatile long sentShiftr   = 0;

//*************************************************************
// MQTT Topics
//*************************************************************
char topicShiftr[61];
char topicTemp[61], topicHumid[61], topicCo2[61];
char topicPm1[61], topicPm25[61], topicPm10[61];

//*************************************************************
// Function Prototypes
//*************************************************************
void TaskWiFi(void *pvParameters);
void TaskI2C(void *pvParameters);
void TaskMQTT(void *pvParameters);
void TaskMonitor(void *pvParameters);

bool readFromNano33WithRetry(char *outBuffer, size_t outSize);
void publishLatestData();
bool connectShiftr();
bool connectHive();

//*************************************************************
void setup() {
  Serial.begin(115200);
  delay(1500);

  Serial.println();
  Serial.println("======================================");
  Serial.println(" ESP32 Gateway FreeRTOS Version");
  Serial.println(" Nano33 I2C -> MQTT Hive + Shiftr");
  Serial.println("======================================");

  // I2C Master
  Wire.begin(I2C_SDA, I2C_SCL);
  Wire.setClock(100000);
  Serial.println("I2C Master ready");

  // MQTT Topics
  snprintf(topicShiftr, sizeof(topicShiftr), "gmu/ece508/%s", TEAM_NUM);

  snprintf(topicTemp,  sizeof(topicTemp),  "airmonitor/%s/nano33iot/sht31/temp",   G_NUMBER);
  snprintf(topicHumid, sizeof(topicHumid), "airmonitor/%s/nano33iot/sht31/humid",  G_NUMBER);
  snprintf(topicCo2,   sizeof(topicCo2),   "airmonitor/%s/nano33iot/scd41/co2",    G_NUMBER);
  snprintf(topicPm1,   sizeof(topicPm1),   "airmonitor/%s/nano33iot/pms5003/pm1",  G_NUMBER);
  snprintf(topicPm25,  sizeof(topicPm25),  "airmonitor/%s/nano33iot/pms5003/pm25", G_NUMBER);
  snprintf(topicPm10,  sizeof(topicPm10),  "airmonitor/%s/nano33iot/pms5003/pm10", G_NUMBER);

  // MQTT Setup
  mqttShiftr.setServer(SHIFTR_HOST, SHIFTR_PORT);

  wifiSSL.setInsecure();
  mqttHive.setServer(HIVE_HOST, HIVE_PORT);
  mqttHive.setBufferSize(512);

  // Mutex
  dataMutex = xSemaphoreCreateMutex();
  if (dataMutex == NULL) {
    Serial.println("ERROR: failed to create data mutex");
    while (1) delay(1000);
  }

  // WiFi Start
  WiFi.mode(WIFI_STA);
  WiFi.begin(SSID, PASS);

  // Tasks
  xTaskCreate(TaskWiFi,    "WiFi",    4096, NULL, 4, &Handle_TaskWiFi);
  xTaskCreate(TaskI2C,     "I2C",     4096, NULL, 3, &Handle_TaskI2C);
  xTaskCreate(TaskMQTT,    "MQTT",    8192, NULL, 2, &Handle_TaskMQTT);
  xTaskCreate(TaskMonitor, "Monitor", 4096, NULL, 1, &Handle_TaskMonitor);

  Serial.println("RTOS tasks started");
}

void loop() {
  // Empty because FreeRTOS tasks handle everything
}

//*************************************************************
// Task 1: WiFi
//*************************************************************
void TaskWiFi(void *pvParameters) {
  (void) pvParameters;

  for (;;) {
    if (WiFi.status() != WL_CONNECTED) {
      Serial.print("[WiFi] Connecting");

      WiFi.disconnect();
      delay(200);
      WiFi.begin(SSID, PASS);

      unsigned long start = millis();
      while (WiFi.status() != WL_CONNECTED && millis() - start < 10000) {
        Serial.print(".");
        vTaskDelay(pdMS_TO_TICKS(500));
      }

      if (WiFi.status() == WL_CONNECTED) {
        Serial.println(" OK!");
        Serial.print("[WiFi] IP: ");
        Serial.println(WiFi.localIP());
      } else {
        Serial.println(" failed");
      }
    }

    vTaskDelay(pdMS_TO_TICKS(5000));
  }
}

//*************************************************************
// Task 2: I2C Read from Nano33
//*************************************************************
void TaskI2C(void *pvParameters) {
  (void) pvParameters;

  TickType_t lastWake = xTaskGetTickCount();

  for (;;) {
    char tempBuffer[I2C_BUF_SIZE];

    if (readFromNano33WithRetry(tempBuffer, sizeof(tempBuffer))) {
      if (xSemaphoreTake(dataMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
        strncpy(latestJson, tempBuffer, sizeof(latestJson) - 1);
        latestJson[sizeof(latestJson) - 1] = '\0';
        hasLatestData = true;
        xSemaphoreGive(dataMutex);
      }
    }

    vTaskDelayUntil(&lastWake, pdMS_TO_TICKS(I2C_READ_INTERVAL_MS));
  }
}

//*************************************************************
// Task 3: MQTT
//*************************************************************
void TaskMQTT(void *pvParameters) {
  (void) pvParameters;

  unsigned long lastHivePublish = 0;
  unsigned long lastShiftrPublish = 0;

  for (;;) {
    if (WiFi.status() == WL_CONNECTED) {
      if (!mqttShiftr.connected()) {
        connectShiftr();
      }

      if (!mqttHive.connected()) {
        connectHive();
      }

      mqttShiftr.loop();
      mqttHive.loop();

      unsigned long now = millis();

      if (now - lastHivePublish >= HIVE_INTERVAL_MS) {
        lastHivePublish = now;
        publishLatestData();
      }

      if (now - lastShiftrPublish >= SHIFTR_INTERVAL_MS) {
        lastShiftrPublish = now;

        char jsonCopy[I2C_BUF_SIZE];
        bool ready = false;

        if (xSemaphoreTake(dataMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
          if (hasLatestData) {
            strncpy(jsonCopy, latestJson, sizeof(jsonCopy) - 1);
            jsonCopy[sizeof(jsonCopy) - 1] = '\0';
            ready = true;
          }
          xSemaphoreGive(dataMutex);
        }

        if (ready && mqttShiftr.connected()) {
          bool ok = mqttShiftr.publish(topicShiftr, jsonCopy);
          sentShiftr++;

          Serial.print("[Shiftr] #");
          Serial.print(sentShiftr);
          Serial.print(" ");
          Serial.println(ok ? "OK" : "FAIL");
        }
      }
    }

    vTaskDelay(pdMS_TO_TICKS(50));
  }
}

//*************************************************************
// Task 4: Monitor
//*************************************************************
void TaskMonitor(void *pvParameters) {
  (void) pvParameters;

  for (;;) {
    vTaskDelay(pdMS_TO_TICKS(10000));

    Serial.println();
    Serial.println("****************************************************");
    Serial.print("WiFi: ");
    Serial.println(WiFi.status() == WL_CONNECTED ? "Connected" : "Disconnected");

    Serial.print("I2C attempts: ");
    Serial.println(readAttempts);

    Serial.print("I2C success: ");
    Serial.println(readSuccess);

    if (readAttempts > 0) {
      Serial.print("I2C success rate: ");
      Serial.print((readSuccess * 100.0) / readAttempts, 1);
      Serial.println("%");
    }

    Serial.print("Hive sent: ");
    Serial.println(sentHive);

    Serial.print("Shiftr sent: ");
    Serial.println(sentShiftr);

    if (xSemaphoreTake(dataMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
      Serial.print("Latest JSON: ");
      Serial.println(latestJson);
      xSemaphoreGive(dataMutex);
    }

    Serial.println("****************************************************");
  }
}

//*************************************************************
// Read JSON from Nano33 with retry
//*************************************************************
bool readFromNano33WithRetry(char *outBuffer, size_t outSize) {
  const int MAX_RETRIES = 5;
  const int RETRY_DELAY_MS = 150;

  for (int attempt = 1; attempt <= MAX_RETRIES; attempt++) {
    readAttempts++;

    Wire.requestFrom((uint8_t)NANO_ADDR, (uint8_t)I2C_BUF_SIZE);

    int idx = 0;

    while (Wire.available() && idx < (int)outSize - 1) {
      char c = Wire.read();

      if (c == 0 || c == 0xFF) {
        break;
      }

      outBuffer[idx++] = c;
    }

    outBuffer[idx] = '\0';

    // Accept only complete JSON
    if (idx > 10 && outBuffer[0] == '{' && outBuffer[idx - 1] == '}') {
      readSuccess++;

      Serial.print("[I2C] ");
      Serial.print(idx);
      Serial.print("B attempt ");
      Serial.print(attempt);
      Serial.print(": ");
      Serial.println(outBuffer);

      return true;
    }

    vTaskDelay(pdMS_TO_TICKS(RETRY_DELAY_MS));
  }

  Serial.println("[I2C] Failed: no complete JSON from Nano33");
  return false;
}

//*************************************************************
// Publish latest data to HiveMQ every 1 second
//*************************************************************
void publishLatestData() {
  char jsonCopy[I2C_BUF_SIZE];
  bool ready = false;

  if (xSemaphoreTake(dataMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
    if (hasLatestData) {
      strncpy(jsonCopy, latestJson, sizeof(jsonCopy) - 1);
      jsonCopy[sizeof(jsonCopy) - 1] = '\0';
      ready = true;
    }
    xSemaphoreGive(dataMutex);
  }

  if (!ready) {
    return;
  }

  StaticJsonDocument<384> doc;
  DeserializationError err = deserializeJson(doc, jsonCopy);

  if (err) {
    Serial.print("[MQTT] JSON parse error: ");
    Serial.println(err.c_str());
    return;
  }

  const char* sTemp  = doc["temp"]  | "0";
  const char* sHumid = doc["humid"] | "0";
  const char* sCo2   = doc["co2"]   | "0";
  const char* sPm1   = doc["pm1"]   | "0";
  const char* sPm25  = doc["pm25"]  | "0";
  const char* sPm10  = doc["pm10"]  | "0";

  if (mqttHive.connected()) {
    bool ok1 = mqttHive.publish(topicTemp,  sTemp);
    bool ok2 = mqttHive.publish(topicHumid, sHumid);
    bool ok3 = mqttHive.publish(topicCo2,   sCo2);
    bool ok4 = mqttHive.publish(topicPm1,   sPm1);
    bool ok5 = mqttHive.publish(topicPm25,  sPm25);
    bool ok6 = mqttHive.publish(topicPm10,  sPm10);

    sentHive++;

    Serial.print("[Hive] #");
    Serial.print(sentHive);
    Serial.print(" [");
    Serial.print(ok1 ? "T" : "-");
    Serial.print(ok2 ? "H" : "-");
    Serial.print(ok3 ? "C" : "-");
    Serial.print(ok4 ? "1" : "-");
    Serial.print(ok5 ? "2" : "-");
    Serial.print(ok6 ? "0" : "-");
    Serial.println("]");
  }
}

//*************************************************************
// MQTT Connect Helpers
//*************************************************************
bool connectShiftr() {
  Serial.print("[Shiftr] Connecting... ");

  String clientId = "esp32_shf_" + String(random(0xffff), HEX);

  if (mqttShiftr.connect(clientId.c_str(), SHIFTR_USER, SHIFTR_PASS)) {
    Serial.println("OK");
    return true;
  } else {
    Serial.print("FAIL rc=");
    Serial.println(mqttShiftr.state());
    return false;
  }
}

bool connectHive() {
  Serial.print("[Hive] Connecting... ");

  String clientId = "esp32_hive_" + String(random(0xffff), HEX);

  if (mqttHive.connect(clientId.c_str(), HIVE_USER, HIVE_PASS)) {
    Serial.println("OK");
    return true;
  } else {
    Serial.print("FAIL rc=");
    Serial.println(mqttHive.state());
    return false;
  }
}
