***Additional Library***

\*\*\*Arduino Nano 33 IoT Libraries\*\*\*

1.FreeRTOS_SAMD21 

2.Adafruit SHT31 Library 

3.Sensirion I2C SCD4x 

4.Adafruit PM25 AQI Sensor 5.Adafruit GFX Library 

6.Adafruit SSD1306 

7.SSD1306Ascii 



\*\*\*ESP32-C3 Libraries\*\*\*

1.PubSubClient 

2.ArduinoJson 

3.Adafruit GFX Library 

4.Adafruit SSD1306 

5.ECEFinal_inferencing.h (Zip File)





***\*\*\*\*Keep log from MQTT from public.cloud.shiftr.io\*\*\*\****

run file "savelog.ipynb" to keep log in "mqtt_payload_log





***\*\*\*\*Dash Board\*\*\*\*\****

run via Docker

1.NodeRed
-Dash Board

-ChatGPT Analyse

-line Notify

2.InfluxDB



