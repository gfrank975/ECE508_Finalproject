/**************************************************************************
  Class: ECE508 Spring 2026
  Student Name: Sirawich Sutthawaho, Thanawat Nookhao
  Gnumber: Gxxxx3925-5069
  Date: 05/11/2026
  HW: Final Project — ESP-32 (Master Mode)
 **************************************************************************/

#include <Wire.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <ECEFinal_inferencing.h>

//*************************************************************
// WiFi Config
//*************************************************************
const char* SSID = "xxxxxxxxxx";           //Your SSID
const char* PASS = "xxxxxxxxxx";           //Your WiFi pass

//*************************************************************
// I2C Config: ESP32 <-> TCA9548A main bus
//*************************************************************
#define I2C_SDA         4
#define I2C_SCL         5
#define I2C_BUF_SIZE    220

//*************************************************************
// TCA9548A Config
//*************************************************************
#define TCA_ADDR        0x70
#define IOT33_CHANNEL   0
#define OLED_CHANNEL    1

//*************************************************************
// IoT33 Config
//*************************************************************
#define NANO_ADDR       0x08

//*************************************************************
// OLED Config through TCA Channel 1
//*************************************************************
#define OLED_ADDR       0x3C
#define SCREEN_WIDTH    128
#define SCREEN_HEIGHT   64

Adafruit_SSD1306 espOled(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);
bool espOledReady = false;

//*************************************************************
// Built-in RGB LED Config
//*************************************************************
#define RGB_LED_PIN     8

//*************************************************************
// MQTT Config
//*************************************************************
const char* SHIFTR_HOST = "public.cloud.shiftr.io";
const char* SHIFTR_USER = "public";
const char* SHIFTR_PASS = "public";
const int   SHIFTR_PORT = 1883;

const char* HIVE_HOST = "xxxxxxxxx";   //Hive Host get from hivemq.cloud
const char* HIVE_USER = "xxxxx";       //Hive User get from hivemq.cloud
const char* HIVE_PASS = "xxxxx";       //Hive Pass get from hivemq.cloud
const int   HIVE_PORT = 8883;

const char* TEAM_NUM = "team03";       //Add your team
const char* G_NUMBER = "Gxxxx3925";    //Add your G-number

//*************************************************************
// Timing
//*************************************************************
const unsigned long I2C_READ_INTERVAL_MS = 1000;
const unsigned long HIVE_INTERVAL_MS     = 1000;
const unsigned long SHIFTR_INTERVAL_MS   = 3000;
const unsigned long EI_INTERVAL_MS       = 1000;

//*************************************************************
// Objects
//*************************************************************
WiFiClient        wifiPlain;
WiFiClientSecure wifiSSL;
PubSubClient     mqttShiftr(wifiPlain);
PubSubClient     mqttHive(wifiSSL);

//*************************************************************
// RTOS Handles
//*************************************************************
TaskHandle_t Handle_TaskWiFi;
TaskHandle_t Handle_TaskI2C;
TaskHandle_t Handle_TaskMQTT;
TaskHandle_t Handle_TaskMonitor;
TaskHandle_t Handle_TaskEI;

SemaphoreHandle_t dataMutex;
SemaphoreHandle_t i2cMutex;

//*************************************************************
// Shared Data
//*************************************************************
char latestJson[I2C_BUF_SIZE] = "";
bool hasLatestData = false;

volatile long readAttempts = 0;
volatile long readSuccess  = 0;
volatile long sentHive     = 0;
volatile long sentShiftr   = 0;

String latestClass = "--";
float latestConfidence = 0.0;

//*************************************************************
// MQTT Topics
//*************************************************************
char topicShiftr[80];
char topicTemp[80], topicHumid[80], topicCo2[80];
char topicPm1[80], topicPm25[80], topicPm10[80];

//*************************************************************
// Function Prototypes
//*************************************************************
void TaskWiFi(void *pvParameters);
void TaskI2C(void *pvParameters);
void TaskMQTT(void *pvParameters);
void TaskMonitor(void *pvParameters);
void TaskEI(void *pvParameters);

bool readFromNano33WithRetry(char *outBuffer, size_t outSize);
void publishLatestData();
bool connectShiftr();
bool connectHive();

bool tcaSelect(uint8_t channel);
void tcaDisableAll();

void startESP32OLED();
void updateOLEDWithClass(String airClass, float confidence);

float getJsonFloat(StaticJsonDocument<384> &doc, const char *key);
bool runEdgeImpulseFromJson(const char *jsonText, String &predictedClass, float &confidence);
String applySafetyRule(float humidity, float co2, float pm25, float pm10, String eiClass);
void setRGBByClass(String airClass);

//*************************************************************
// SETUP
//*************************************************************
void setup() {
  Serial.begin(115200);
  delay(1500);

  Serial.println();
  Serial.println("======================================");
  Serial.println(" ESP32 + TCA9548A + Edge Impulse");
  Serial.println(" CH0 -> IoT33, CH1 -> OLED");
  Serial.println(" RGB: good/risky/bad");
  Serial.println(" Hybrid AI + Rule Check");
  Serial.println("======================================");

  Wire.begin(I2C_SDA, I2C_SCL);
  Wire.setClock(100000);
  Serial.println("[I2C] ESP32 -> TCA main bus ready on GPIO4/GPIO5");

  dataMutex = xSemaphoreCreateMutex();
  i2cMutex  = xSemaphoreCreateMutex();

  if (dataMutex == NULL || i2cMutex == NULL) {
    Serial.println("ERROR: failed to create mutex");
    while (1) delay(1000);
  }

  // Turn off RGB at startup
  neopixelWrite(RGB_LED_PIN, 0, 0, 0);

  startESP32OLED();

  snprintf(topicShiftr, sizeof(topicShiftr), "gmu/ece508/%s", TEAM_NUM);

  snprintf(topicTemp,  sizeof(topicTemp),  "airmonitor/%s/nano33iot/sht31/temp",   G_NUMBER);
  snprintf(topicHumid, sizeof(topicHumid), "airmonitor/%s/nano33iot/sht31/humid",  G_NUMBER);
  snprintf(topicCo2,   sizeof(topicCo2),   "airmonitor/%s/nano33iot/scd41/co2",    G_NUMBER);
  snprintf(topicPm1,   sizeof(topicPm1),   "airmonitor/%s/nano33iot/pms5003/pm1",  G_NUMBER);
  snprintf(topicPm25,  sizeof(topicPm25),  "airmonitor/%s/nano33iot/pms5003/pm25", G_NUMBER);
  snprintf(topicPm10,  sizeof(topicPm10),  "airmonitor/%s/nano33iot/pms5003/pm10", G_NUMBER);

  mqttShiftr.setServer(SHIFTR_HOST, SHIFTR_PORT);

  wifiSSL.setInsecure();
  mqttHive.setServer(HIVE_HOST, HIVE_PORT);
  mqttHive.setBufferSize(512);

  WiFi.mode(WIFI_STA);
  WiFi.begin(SSID, PASS);

  xTaskCreate(TaskWiFi,    "WiFi",    4096, NULL, 4, &Handle_TaskWiFi);
  xTaskCreate(TaskI2C,     "I2C",     4096, NULL, 3, &Handle_TaskI2C);
  xTaskCreate(TaskMQTT,    "MQTT",    8192, NULL, 2, &Handle_TaskMQTT);
  xTaskCreate(TaskMonitor, "Monitor", 4096, NULL, 1, &Handle_TaskMonitor);
  xTaskCreate(TaskEI,      "EI",      8192, NULL, 1, &Handle_TaskEI);

  Serial.println("RTOS tasks started");
}

void loop() {
  // Empty because FreeRTOS tasks handle everything
}

//*************************************************************
// TCA9548A Helpers
//*************************************************************
bool tcaSelect(uint8_t channel) {
  if (channel > 7) return false;

  Wire.beginTransmission(TCA_ADDR);
  Wire.write(1 << channel);
  byte err = Wire.endTransmission();

  if (err != 0) {
    Serial.print("[TCA] Select channel failed, error=");
    Serial.println(err);
    return false;
  }

  return true;
}

void tcaDisableAll() {
  Wire.beginTransmission(TCA_ADDR);
  Wire.write(0x00);
  Wire.endTransmission();
}

//*************************************************************
// Task 1: WiFi
//*************************************************************
void TaskWiFi(void *pvParameters) {
  (void) pvParameters;

  for (;;) {
    if (WiFi.status() != WL_CONNECTED) {
      Serial.print("[WiFi] Connecting");

      WiFi.disconnect();
      delay(200);
      WiFi.begin(SSID, PASS);

      unsigned long start = millis();

      while (WiFi.status() != WL_CONNECTED && millis() - start < 10000) {
        Serial.print(".");
        vTaskDelay(pdMS_TO_TICKS(500));
      }

      if (WiFi.status() == WL_CONNECTED) {
        Serial.println(" OK!");
        Serial.print("[WiFi] IP: ");
        Serial.println(WiFi.localIP());
      } else {
        Serial.println(" failed");
      }
    }

    vTaskDelay(pdMS_TO_TICKS(5000));
  }
}

//*************************************************************
// Task 2: I2C Read from IoT33 through TCA CH0
//*************************************************************
void TaskI2C(void *pvParameters) {
  (void) pvParameters;

  TickType_t lastWake = xTaskGetTickCount();

  for (;;) {
    char tempBuffer[I2C_BUF_SIZE];

    if (readFromNano33WithRetry(tempBuffer, sizeof(tempBuffer))) {
      if (xSemaphoreTake(dataMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
        strncpy(latestJson, tempBuffer, sizeof(latestJson) - 1);
        latestJson[sizeof(latestJson) - 1] = '\0';
        hasLatestData = true;
        xSemaphoreGive(dataMutex);
      }
    }

    vTaskDelayUntil(&lastWake, pdMS_TO_TICKS(I2C_READ_INTERVAL_MS));
  }
}

//*************************************************************
// Task 3: MQTT
//*************************************************************
void TaskMQTT(void *pvParameters) {
  (void) pvParameters;

  unsigned long lastHivePublish = 0;
  unsigned long lastShiftrPublish = 0;

  for (;;) {
    if (WiFi.status() == WL_CONNECTED) {
      if (!mqttShiftr.connected()) {
        connectShiftr();
      }

      if (!mqttHive.connected()) {
        connectHive();
      }

      mqttShiftr.loop();
      mqttHive.loop();

      unsigned long now = millis();

      if (now - lastHivePublish >= HIVE_INTERVAL_MS) {
        lastHivePublish = now;
        publishLatestData();
      }

      if (now - lastShiftrPublish >= SHIFTR_INTERVAL_MS) {
        lastShiftrPublish = now;

        char jsonCopy[I2C_BUF_SIZE];
        bool ready = false;

        if (xSemaphoreTake(dataMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
          if (hasLatestData) {
            strncpy(jsonCopy, latestJson, sizeof(jsonCopy) - 1);
            jsonCopy[sizeof(jsonCopy) - 1] = '\0';
            ready = true;
          }
          xSemaphoreGive(dataMutex);
        }

        if (ready && mqttShiftr.connected()) {
          bool ok = mqttShiftr.publish(topicShiftr, jsonCopy);
          sentShiftr++;

          Serial.print("[Shiftr] #");
          Serial.print(sentShiftr);
          Serial.print(" ");
          Serial.println(ok ? "OK" : "FAIL");
        }
      }
    }

    vTaskDelay(pdMS_TO_TICKS(50));
  }
}

//*************************************************************
// Task 4: Monitor
//*************************************************************
void TaskMonitor(void *pvParameters) {
  (void) pvParameters;

  for (;;) {
    vTaskDelay(pdMS_TO_TICKS(10000));

    Serial.println();
    Serial.println("****************************************************");

    Serial.print("WiFi: ");
    Serial.println(WiFi.status() == WL_CONNECTED ? "Connected" : "Disconnected");

    Serial.print("I2C attempts: ");
    Serial.println(readAttempts);

    Serial.print("I2C success: ");
    Serial.println(readSuccess);

    if (readAttempts > 0) {
      Serial.print("I2C success rate: ");
      Serial.print((readSuccess * 100.0) / readAttempts, 1);
      Serial.println("%");
    }

    Serial.print("Hive sent: ");
    Serial.println(sentHive);

    Serial.print("Shiftr sent: ");
    Serial.println(sentShiftr);

    Serial.print("Final class: ");
    Serial.print(latestClass);
    Serial.print(" confidence: ");
    Serial.println(latestConfidence, 4);

    if (xSemaphoreTake(dataMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
      Serial.print("Latest JSON: ");
      Serial.println(latestJson);
      xSemaphoreGive(dataMutex);
    }

    Serial.println("****************************************************");
  }
}

//*************************************************************
// Task 5: Edge Impulse + Rule Check + OLED + RGB
//*************************************************************
void TaskEI(void *pvParameters) {
  (void) pvParameters;

  TickType_t lastWake = xTaskGetTickCount();

  for (;;) {
    char jsonCopy[I2C_BUF_SIZE];
    bool ready = false;

    if (xSemaphoreTake(dataMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
      if (hasLatestData) {
        strncpy(jsonCopy, latestJson, sizeof(jsonCopy) - 1);
        jsonCopy[sizeof(jsonCopy) - 1] = '\0';
        ready = true;
      }
      xSemaphoreGive(dataMutex);
    }

    if (ready) {
      String predictedClass = "--";
      float confidence = 0.0;

      if (runEdgeImpulseFromJson(jsonCopy, predictedClass, confidence)) {
        latestClass = predictedClass;
        latestConfidence = confidence;

        setRGBByClass(predictedClass);
        updateOLEDWithClass(predictedClass, confidence);
      }
    }

    vTaskDelayUntil(&lastWake, pdMS_TO_TICKS(EI_INTERVAL_MS));
  }
}

//*************************************************************
// Read JSON from IoT33 through TCA CH0
//*************************************************************
bool readFromNano33WithRetry(char *outBuffer, size_t outSize) {
  const int MAX_RETRIES = 5;
  const int RETRY_DELAY_MS = 150;

  for (int attempt = 1; attempt <= MAX_RETRIES; attempt++) {
    readAttempts++;

    if (xSemaphoreTake(i2cMutex, pdMS_TO_TICKS(200)) == pdTRUE) {
      if (!tcaSelect(IOT33_CHANNEL)) {
        tcaDisableAll();
        xSemaphoreGive(i2cMutex);
        vTaskDelay(pdMS_TO_TICKS(RETRY_DELAY_MS));
        continue;
      }

      delay(2);

      Wire.requestFrom((uint8_t)NANO_ADDR, (uint8_t)I2C_BUF_SIZE);

      int idx = 0;

      while (Wire.available() && idx < (int)outSize - 1) {
        char c = Wire.read();

        if (c == 0 || c == 0xFF) {
          break;
        }

        outBuffer[idx++] = c;
      }

      outBuffer[idx] = '\0';

      tcaDisableAll();
      xSemaphoreGive(i2cMutex);

      if (idx > 10 && outBuffer[0] == '{' && outBuffer[idx - 1] == '}') {
        readSuccess++;

        Serial.print("[I2C CH0] ");
        Serial.print(idx);
        Serial.print("B attempt ");
        Serial.print(attempt);
        Serial.print(": ");
        Serial.println(outBuffer);

        return true;
      }
    }

    vTaskDelay(pdMS_TO_TICKS(RETRY_DELAY_MS));
  }

  Serial.println("[I2C CH0] Failed: no complete JSON from IoT33");
  return false;
}

//*************************************************************
// Publish latest data to HiveMQ every 1 second
//*************************************************************
void publishLatestData() {
  char jsonCopy[I2C_BUF_SIZE];
  bool ready = false;

  if (xSemaphoreTake(dataMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
    if (hasLatestData) {
      strncpy(jsonCopy, latestJson, sizeof(jsonCopy) - 1);
      jsonCopy[sizeof(jsonCopy) - 1] = '\0';
      ready = true;
    }
    xSemaphoreGive(dataMutex);
  }

  if (!ready) {
    return;
  }

  StaticJsonDocument<384> doc;
  DeserializationError err = deserializeJson(doc, jsonCopy);

  if (err) {
    Serial.print("[MQTT] JSON parse error: ");
    Serial.println(err.c_str());
    return;
  }

  const char* sTemp  = doc["temp"]  | "0";
  const char* sHumid = doc["humid"] | "0";
  const char* sCo2   = doc["co2"]   | "0";
  const char* sPm1   = doc["pm1"]   | "0";
  const char* sPm25  = doc["pm25"]  | "0";
  const char* sPm10  = doc["pm10"]  | "0";

  if (mqttHive.connected()) {
    bool ok1 = mqttHive.publish(topicTemp,  sTemp);
    bool ok2 = mqttHive.publish(topicHumid, sHumid);
    bool ok3 = mqttHive.publish(topicCo2,   sCo2);
    bool ok4 = mqttHive.publish(topicPm1,   sPm1);
    bool ok5 = mqttHive.publish(topicPm25,  sPm25);
    bool ok6 = mqttHive.publish(topicPm10,  sPm10);

    sentHive++;

    Serial.print("[Hive] #");
    Serial.print(sentHive);
    Serial.print(" [");
    Serial.print(ok1 ? "T" : "-");
    Serial.print(ok2 ? "H" : "-");
    Serial.print(ok3 ? "C" : "-");
    Serial.print(ok4 ? "1" : "-");
    Serial.print(ok5 ? "2" : "-");
    Serial.print(ok6 ? "0" : "-");
    Serial.println("]");
  }
}

//*************************************************************
// MQTT Connect Helpers
//*************************************************************
bool connectShiftr() {
  Serial.print("[Shiftr] Connecting... ");

  String clientId = "esp32_shf_" + String(random(0xffff), HEX);

  if (mqttShiftr.connect(clientId.c_str(), SHIFTR_USER, SHIFTR_PASS)) {
    Serial.println("OK");
    return true;
  } else {
    Serial.print("FAIL rc=");
    Serial.println(mqttShiftr.state());
    return false;
  }
}

bool connectHive() {
  Serial.print("[Hive] Connecting... ");

  String clientId = "esp32_hive_" + String(random(0xffff), HEX);

  if (mqttHive.connect(clientId.c_str(), HIVE_USER, HIVE_PASS)) {
    Serial.println("OK");
    return true;
  } else {
    Serial.print("FAIL rc=");
    Serial.println(mqttHive.state());
    return false;
  }
}

//*************************************************************
// Start OLED through TCA CH1
//*************************************************************
void startESP32OLED() {
  if (xSemaphoreTake(i2cMutex, pdMS_TO_TICKS(500)) == pdTRUE) {
    if (!tcaSelect(OLED_CHANNEL)) {
      Serial.println("[OLED] Could not select TCA CH1");
      espOledReady = false;
      xSemaphoreGive(i2cMutex);
      return;
    }

    delay(10);

    if (!espOled.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR)) {
      Serial.println("[OLED] OLED failed on TCA CH1");
      espOledReady = false;
      tcaDisableAll();
      xSemaphoreGive(i2cMutex);
      return;
    }

    espOled.clearDisplay();
    espOled.setTextSize(1);
    espOled.setTextColor(SSD1306_WHITE);
    espOled.setCursor(0, 0);

    espOled.println("Air Quality");
    espOled.println("Waiting data...");
    espOled.display();

    espOledReady = true;

    tcaDisableAll();
    xSemaphoreGive(i2cMutex);

    Serial.println("[OLED] OLED ready on TCA CH1");
  }
}

//*************************************************************
// Update OLED with final class
//*************************************************************
void updateOLEDWithClass(String airClass, float confidence) {
  if (!espOledReady) return;

  static String lastClass = "";
  static int lastConfInt = -1;

  int confInt = (int)(confidence * 100.0);

  if (airClass == lastClass && confInt == lastConfInt) {
    return;
  }

  lastClass = airClass;
  lastConfInt = confInt;

  if (xSemaphoreTake(i2cMutex, pdMS_TO_TICKS(200)) == pdTRUE) {
    if (!tcaSelect(OLED_CHANNEL)) {
      xSemaphoreGive(i2cMutex);
      return;
    }

    delay(2);

    espOled.clearDisplay();
    espOled.setTextColor(SSD1306_WHITE);

    espOled.setTextSize(1);
    espOled.setCursor(0, 0);
    espOled.println("Air Quality");

    espOled.setTextSize(2);
    espOled.setCursor(0, 20);
    espOled.println(airClass);

    espOled.setTextSize(1);
    espOled.setCursor(0, 52);
    espOled.print("Conf: ");
    espOled.print(confidence * 100.0, 1);
    espOled.println("%");

    espOled.display();

    tcaDisableAll();
    xSemaphoreGive(i2cMutex);
  }
}

//*************************************************************
// Convert JSON value to float
//*************************************************************
float getJsonFloat(StaticJsonDocument<384> &doc, const char *key) {
  if (doc[key].is<const char*>()) {
    return atof(doc[key].as<const char*>());
  }

  return doc[key] | 0.0f;
}

//*************************************************************
// Rule-based safety check
// This runs locally on ESP32, still edge computing.
//*************************************************************
String applySafetyRule(float humidity, float co2, float pm25, float pm10, String eiClass) {
  // Bad air threshold
  if (co2 > 1500 || pm25 > 75 || pm10 > 150 || humidity > 80) {
    return "bad";
  }

  // Risky air threshold
  if (co2 >= 800 || pm25 >= 15 || pm10 >= 45 || humidity >= 60) {
    return "risky";
  }

  // Otherwise keep Edge Impulse result
  return eiClass;
}

//*************************************************************
// Run Edge Impulse classification from latest JSON
//*************************************************************
bool runEdgeImpulseFromJson(const char *jsonText, String &predictedClass, float &confidence) {
  StaticJsonDocument<384> doc;
  DeserializationError err = deserializeJson(doc, jsonText);

  if (err) {
    Serial.print("[EI] JSON parse error: ");
    Serial.println(err.c_str());
    return false;
  }

  float temperature = getJsonFloat(doc, "temp");
  float humidity    = getJsonFloat(doc, "humid");
  float co2         = getJsonFloat(doc, "co2");
  float pm1         = getJsonFloat(doc, "pm1");
  float pm25        = getJsonFloat(doc, "pm25");
  float pm10        = getJsonFloat(doc, "pm10");

  float oneSample[6] = {
    temperature,
    humidity,
    co2,
    pm1,
    pm25,
    pm10
  };

  static float features[EI_CLASSIFIER_DSP_INPUT_FRAME_SIZE];

  for (size_t i = 0; i < EI_CLASSIFIER_DSP_INPUT_FRAME_SIZE; i++) {
    features[i] = oneSample[i % 6];
  }

  signal_t signal;
  int signalResult = numpy::signal_from_buffer(
    features,
    EI_CLASSIFIER_DSP_INPUT_FRAME_SIZE,
    &signal
  );

  if (signalResult != 0) {
    Serial.println("[EI] Failed to create signal");
    return false;
  }

  ei_impulse_result_t result = { 0 };

  EI_IMPULSE_ERROR res = run_classifier(&signal, &result, false);

  if (res != EI_IMPULSE_OK) {
    Serial.print("[EI] run_classifier failed: ");
    Serial.println(res);
    return false;
  }

  float bestValue = 0.0;
  String bestLabel = "--";

  for (size_t ix = 0; ix < EI_CLASSIFIER_LABEL_COUNT; ix++) {
    float value = result.classification[ix].value;
    String label = String(result.classification[ix].label);

    Serial.print("[EI] ");
    Serial.print(label);
    Serial.print(": ");
    Serial.println(value, 4);

    if (value > bestValue) {
      bestValue = value;
      bestLabel = label;
    }
  }

  String finalClass = applySafetyRule(humidity, co2, pm25, pm10, bestLabel);

  predictedClass = finalClass;
  confidence = bestValue;

  Serial.print("[EI] Raw predicted: ");
  Serial.print(bestLabel);
  Serial.print(" | Final class: ");
  Serial.print(predictedClass);
  Serial.print(" | confidence=");
  Serial.println(confidence, 4);

  return true;
}

//*************************************************************
// RGB LED color based on final class using ESP32 built-in neopixelWrite
// good  = green
// risky = yellow
// bad   = red
//*************************************************************
void setRGBByClass(String airClass) {
  airClass.toLowerCase();

  if (airClass == "good") {
    neopixelWrite(RGB_LED_PIN, 0, 80, 0);       // Green
  }
  else if (airClass == "risky" || airClass == "risk") {
    neopixelWrite(RGB_LED_PIN, 80, 60, 0);      // Yellow
  }
  else if (airClass == "bad") {
    neopixelWrite(RGB_LED_PIN, 80, 0, 0);       // Red
  }
  else {
    neopixelWrite(RGB_LED_PIN, 0, 0, 0);        // Off
  }
}
